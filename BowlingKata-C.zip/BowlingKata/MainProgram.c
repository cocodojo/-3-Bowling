#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  puts("Run all test:");
  runAllTests();
  system("PAUSE");
  
  char rolls[23];
  
  printf("Enter result: ");	
  gets(rolls);
  printf("Your Scores: %d\n", getScores(rolls));
  
  system("PAUSE");
  
  return 0;
}

