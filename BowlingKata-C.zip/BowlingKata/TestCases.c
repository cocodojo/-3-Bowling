#include "cutest-1.5/CuTest.h"
#include "cutest-1.5/CuTest.c"

void case1(){
     char rollResults[] = "XXXXXXXXXXXX"; 
     int expected = 300;
     printf("%-10s| ","Case 1");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Error!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}

void case2(){
     char rollResults[] = "9-9-9-9-9-9-9-9-9-9-"; 
     int expected = 90;
     printf("%-10s| ","Case 2");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}

void case3(){
     char rollResults[] = "5/5/5/5/5/5/5/5/5/5/5"; 
     int expected = 150;
     printf("%-10s| ","Case 3");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case4(){
     char rollResults[] = "5-5-5-5-5-5-5-5-5-5-"; 
     int expected = 50;
     printf("%-10s| ","Case 4");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case5(){
     char rollResults[] = "5/5/5-5-5-5-5-5-5-5-"; 
     int expected = 70;
     printf("%-10s| ","Case 5");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case6(){
     char rollResults[] = "XXXX------------"; 
     int expected = 90;
     printf("%-10s| ","Case 6");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case7(){
     char rollResults[] = "1-1-1-1-1-1-1-1-X5/5"; 
     int expected = 43;
     printf("%-10s| ","Case 7");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case8(){
     char rollResults[] = "----------------------"; 
     int expected = 0;
     printf("%-10s| ","Case 8");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case9(){
     char rollResults[] = "11111111111111111111"; 
     int expected = 20;
     printf("%-10s| ","Case 9");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case10(){
     char rollResults[] = "5/111111111111111111"; 
     int expected = 29;
     printf("%-10s| ","Case 10");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case11(){
     char rollResults[] = "1111111111111111115/1"; 
     int expected = 29;
     printf("%-10s| ","Case 11");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case12(){
     char rollResults[] = "X111111111111111111"; 
     int expected = 30;
     printf("%-10s| ","Case 12");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case13(){
     char rollResults[] = "111111111111111111X11"; 
     int expected = 30;
     printf("%-10s| ","Case 13");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
void case14(){
     char rollResults[] = "555/5-5-5-5-5-5-5-XXX"; 
     int expected = 90;
     printf("%-10s| ","Case 14");
     
     if(getScores(rollResults)==expected){
          printf("%-12s", "Success!!!");
     }else{
          printf("%-12s Exp:%d <> Res:%d ","Fail!!!", expected, getScores(rollResults) );       
     }    
     
     printf("\n");
}
CuSuite* bowlingGetSuite();

void runAllTests(void) {
    CuString *output = CuStringNew();
    CuSuite* suite = CuSuiteNew();
    
    CuSuiteAddSuite(suite, bowlingGetSuite());

    CuSuiteRun(suite);
    CuSuiteSummary(suite, output);
    CuSuiteDetails(suite, output);
    printf("%s\n", output->buffer);
}

CuSuite* bowlingGetSuite() {
    CuSuite* suite = CuSuiteNew();
    SUITE_ADD_TEST(suite, case1);
    SUITE_ADD_TEST(suite, case2);
    SUITE_ADD_TEST(suite, case3);
    SUITE_ADD_TEST(suite, case4);
    SUITE_ADD_TEST(suite, case5);
    SUITE_ADD_TEST(suite, case6);
    SUITE_ADD_TEST(suite, case7);
    SUITE_ADD_TEST(suite, case8);
    SUITE_ADD_TEST(suite, case9);
    SUITE_ADD_TEST(suite, case10);
    SUITE_ADD_TEST(suite, case11);
    SUITE_ADD_TEST(suite, case12);
    SUITE_ADD_TEST(suite, case13);
    SUITE_ADD_TEST(suite, case14);
    return suite;
}


