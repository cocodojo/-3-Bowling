#define STRIKE_VALUE 'X'
#define SPARE_VALUE '/' 
#define MISS_VALUE '-' 
#define MAX_SCORE 10
#define MIN_SCORE 0
#define TRUE_VALUE 1
#define FALSE_VALUE 0

int isStrike(char roll){
    return (roll==STRIKE_VALUE)?TRUE_VALUE:FALSE_VALUE;    
}

int isSpare(char roll){
    return (roll==SPARE_VALUE)?TRUE_VALUE:FALSE_VALUE;    
}

int isMiss(char roll){
    return (roll==MISS_VALUE)?TRUE_VALUE:FALSE_VALUE;    
}

int isLastFrame(int index, int totalRolls){
    return (index==totalRolls)?TRUE_VALUE:FALSE_VALUE;    
}

int rollScore(char roll){
    char num[2] = "";
    roll = toupper(roll);         
    if(isStrike(roll)){
        return MAX_SCORE;
    }else if(isMiss(roll)){
        return MIN_SCORE;
    }else if(!isSpare(roll)){
        num[0] = roll; //Chuyen thanh chuoi de convert so  
        return atoi(num);             
    }
    return 0;    
}

int strikeScores(char nextRoll, char afterNextRoll){
    int score = 0;
    score+= MAX_SCORE;
    if(!isSpare(afterNextRoll)){
        score+= rollScore(nextRoll);                             
        score+= rollScore(afterNextRoll);
    }else{
        score+= MAX_SCORE;      
    }
    return score;     
}

int spareScores(char preRoll, char nextRoll){
    int score = 0;
    score+= (MAX_SCORE - rollScore(preRoll));                
    score+= rollScore(nextRoll);    
    return score;   
}

int getScores(char* rolls){
    int total = strlen(rolls);
    int i, scores = 0;
    
    for(i=0; i<total; i++){
        char roll = rolls[i]; 
        if(isStrike(roll)){
            if(isLastFrame(i+3, total)){ 
                scores+= strikeScores(rolls[i+1], rolls[i+2]);
                break;
            }else{
                scores+= strikeScores(rolls[i+1], rolls[i+2]);
            }                          
        }else if(isSpare(roll)){
             if(isLastFrame(i+2, total)){ 
                scores+= spareScores(rolls[i-1], rolls[i+1]);
                break;
             }else{
                scores+= spareScores(rolls[i-1], rolls[i+1]);       
             } 
        }else{
             scores+= rollScore(roll);        
        }
    }
    
    return scores;
}


